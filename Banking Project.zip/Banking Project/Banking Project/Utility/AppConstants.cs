﻿

namespace Banking_Project.Utility
{
    public class AppConstants
    {
        public const string REGISTRATION_SUCCESS_MESSAGE = "Customer account created successfully.";

        public const string LOGIN_SUCCESS_MESSAGE = "Login successful";

        public const string INVALID_CREDENTIAL_MESSAGE = "Invalid customername or password";

        public const string LOGOUT_MESSAGE = "Logout successful.";

        public const string TRANSFER_SUCCESS_MESSAGE = "Transfer successful.";

        public const string MINIMUM_BALANCE_ALERT_MESSAGE = "There is no more balance in your account. You will be levied a Minimum maintenance charge.";

        public const string INSUFFICIENT_BALANCE_MESSAGE = "There is insufficient funds in your account.";



    }
}
