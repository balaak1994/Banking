﻿using Microsoft.EntityFrameworkCore;
using Banking_Project.Model;


namespace Banking_Project.DbContexts
{
    public class BankingDbContext : DbContext
    {
        public DbSet<Customer> customers { get; set; }

        public BankingDbContext(DbContextOptions<BankingDbContext> options) : base(options)
        {
        }
    }
}
