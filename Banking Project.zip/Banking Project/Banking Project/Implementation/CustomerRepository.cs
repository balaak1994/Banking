﻿using Banking_Project.Contract;
using Banking_Project.DbContexts;
using Banking_Project.Model;
using System.Linq;

namespace Banking_Project.Implementation
{
    public class CustomerRepository : ICustomerRepository
    {

        private readonly BankingDbContext _dbContext;

        public CustomerRepository(BankingDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void AddCustomer(Customer customer)
        {
            _dbContext.customers.Add(customer);
            _dbContext.SaveChanges();
        }

        public Customer GetUserByUsernameAndPassword(string userName,string password)
        {
            return  _dbContext.customers.FirstOrDefault(u => u.Username == userName && u.Password == password);               
        }
    }
}
