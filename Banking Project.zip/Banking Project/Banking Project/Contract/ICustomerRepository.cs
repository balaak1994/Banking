﻿using Banking_Project.Model;

namespace Banking_Project.Contract
{
    public interface ICustomerRepository
    {
        void AddCustomer(Customer customer);
        Customer GetUserByUsernameAndPassword(string userName, string password);
    }
}
