﻿using Banking_Project.Contract;
using Banking_Project.Model;
using Banking_Project.Utility;
using Microsoft.AspNetCore.Mvc;


namespace Banking_Project.Controllers
{
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerRepository _customerRepository;


        public CustomerController(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        [HttpPost("/customer")]
        public IActionResult CreateUser([FromBody] Customer customer)
        {
            _customerRepository.AddCustomer(customer);
            return Ok(new { message = AppConstants.REGISTRATION_SUCCESS_MESSAGE });
        }
    }
}
