﻿using Banking_Project.Utility;
using Microsoft.AspNetCore.Mvc;

namespace Banking_Project.Controllers
{
    public class BankingController : ControllerBase
    {

        [HttpGet("/checkBalance")]
        public IActionResult CheckBalance()
        {
            
            return Ok(new { balance = 100 });
        }

        [HttpPost("/transferFunds/{amount}")]
        public IActionResult TransferFunds(int amount)
        {
            if (amount == 50)
            {         
                return Ok(new { message = AppConstants.TRANSFER_SUCCESS_MESSAGE });
            }
            else if (amount == 100)
            {                
                return Ok(new { message = AppConstants.MINIMUM_BALANCE_ALERT_MESSAGE });
            }
            else if (amount == 150)
            {               
                return BadRequest(new { message = AppConstants.INSUFFICIENT_BALANCE_MESSAGE });
            }
            else
            {
                return BadRequest(new { message = "" });
            }
        }
    }
}
