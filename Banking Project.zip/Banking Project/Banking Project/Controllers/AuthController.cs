﻿using Banking_Project.Contract;
using Banking_Project.Model;
using Banking_Project.Utility;
using Microsoft.AspNetCore.Mvc;

namespace Banking_Project.Controllers
{
    public class AuthController : ControllerBase
    {

        private readonly ICustomerRepository _customerRepository;

        public AuthController(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        [HttpPost("/login")]
        public IActionResult Login([FromBody] Customer customer)
        {
            var existingUser = _customerRepository.GetUserByUsernameAndPassword(customer.Username, customer.Password);

            if (existingUser != null)
            {
                return Ok(new { message = AppConstants.LOGIN_SUCCESS_MESSAGE });
            }
            else
            {
                return BadRequest(new { message = AppConstants.INVALID_CREDENTIAL_MESSAGE });
            }

        }

        [HttpPost("/logout")]
        public IActionResult Logout()
        {
            return Ok(new { message = AppConstants.LOGOUT_MESSAGE });
        }
    }
}
