﻿using Banking_Project.Contract;
using Banking_Project.Controllers;
using Banking_Project.Model;
using Banking_Project.Utility;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;


namespace BankingProject.Tests.TestMethods
{
    internal class CustomerControllerTests
    {
        [Test]
        public void CreateUser_ValidUser_ReturnsOkResult()
        {
            // Arrange
            var mockRepo = new Mock<ICustomerRepository>();
            var controller = new CustomerController(mockRepo.Object);
            var user = new Customer { Username = "testuser", Password = "password", Balance = 0, Email = "test@gmail.com", Address = "India" };

            // Act
            var result = controller.CreateUser(user) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
            Assert.AreEqual(AppConstants.REGISTRATION_SUCCESS_MESSAGE, result.Value);
        }
    }

    public class AuthControllerTests
    {
        [Test]
        public void Login_ValidUser_ReturnsOkResult()
        {
            // Arrange
            var mockRepo = new Mock<ICustomerRepository>();
            mockRepo.Setup(repo => repo.GetUserByUsernameAndPassword("testuser", "password"))
                .Returns(new Customer { Username = "testuser", Password = "password" });
            var controller = new AuthController(mockRepo.Object);
            var user = new Customer { Username = "testuser", Password = "password" };

            // Act
            var result = controller.Login(user) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
            Assert.AreEqual(AppConstants.LOGIN_SUCCESS_MESSAGE, result.Value);
        }
    }

    public class BankingControllerTests
    {
        [Test]
        public void CheckBalance_ReturnsOkResultWithBalance()
        {
            // Arrange
            var controller = new BankingController();

            // Act
            var result = controller.CheckBalance() as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
            Assert.AreEqual(100, (decimal)result.Value.GetType().GetProperty("balance").GetValue(result.Value));
        }

        [Test]
        public void TransferFunds_Transfer50_ReturnsOkResult()
        {
            // Arrange
            var controller = new BankingController();

            // Act
            var result = controller.TransferFunds(50) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
            Assert.AreEqual(AppConstants.TRANSFER_SUCCESS_MESSAGE, result.Value);
        }

        [Test]
        public void TransferFunds_Transfer100_ReturnsOkResultWithMessage()
        {
            // Arrange
            var controller = new BankingController();

            // Act
            var result = controller.TransferFunds(100) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.StatusCode);
            Assert.AreEqual(AppConstants.MINIMUM_BALANCE_ALERT_MESSAGE, result.Value);
        }

        [Test]
        public void TransferFunds_Transfer150_ReturnsBadRequestResultWithMessage()
        {
            // Arrange
            var controller = new BankingController();

            // Act
            var result = controller.TransferFunds(150) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(400, result.StatusCode);
            Assert.AreEqual(AppConstants.INSUFFICIENT_BALANCE_MESSAGE, result.Value);
        }
    }
}
